//apikey bisa beli langsung ke dev xteam/bisa beli lewat perantara Fernazer
//disini jangan di apa2 in dlu takutnya eror soalnya msih tes
tes = '6867' //apikey nya beli sendiri
tes = 'MatamuCok' // hem
tes = 'SlurrPunten' // hem
  // name: 'https://website'
  nrtm: 'https://Fernazer.herokuapp.com',
  slurPunten: 'https://Fernazer.slurPunten.xyz'
}
global.APIKeys = { // APIKey woy tes
  // 'https://website': 'apikey'
  'https://api.xteam.xyz': 'tesdoang' // untuk keseluruhan fitur
})
tes_doang = 'yhahah wahyu sc numpang jan sok ngaku2 lu'
}